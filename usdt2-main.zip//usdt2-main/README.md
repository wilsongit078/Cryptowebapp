# Usdt
This is just some fake mining site still working on it though but you could use it for fun
# Note
it's for educational purposes only 
# Contact 
Get in touch with me by clicking this link <a href="https://protech-three.vercel.app/">link</a>
