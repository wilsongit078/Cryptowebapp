<?php
echo "server side";