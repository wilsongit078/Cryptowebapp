 <?php
include("assets/classes/autoload.php");
$data = file_get_contents("php://input");//echo $data;die;
if($data != ""){
    
    $data = json_decode($data);
}
if(isset($data->action) && $data->action == "like_post"){
    include "ajax/like.ajax.php";
}
if(isset($data->action) && $data->action == "like_comment"){
    include "ajax/like.ajax.php";
}
if(isset($data->action) && $data->action == "share_post"){
    include "ajax/share.ajax.php";
}